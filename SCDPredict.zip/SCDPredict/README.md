# SCDPredict
This is a mobile application that monitors SCD patients and predicts the likelihood of a crisis.
